from .app import MainGame
from .result import Result

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.going = True

        self.main_game = MainGame(self.screen)
    
    def game(self, name):
        self.game_name = name
        if self.going:
            res = self.main_game.game()
            self.going = res.running
            self.result = res.score
        return Result(self.going, self.result)

