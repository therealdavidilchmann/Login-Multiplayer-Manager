import sys, pygame, random, time, os
from .result import Result

pygame.init()

#press the arrow keys to move player and spacebar to shoot
#you get 1 point for each alien you shoot down, the alien's get 2 points each time they get past you
#your final score = aliens hit - aliens that got past you

BASE = os.path.dirname(__file__)


# CLASSES ------------------------------------------------------------
class Player (pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, vel):
        super().__init__()
        self.screen_width = 900
        self.screen_height = 600
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = vel
        self.surf = pygame.image.load(os.path.join(BASE, "spaceship.png")).convert()
        self.surf = pygame.transform.scale(self.surf,(width, height))
        self.mask = pygame.mask.from_surface(self.surf)
        self.rect = self.surf.get_rect(topleft=(self.x,self.y))    
        
    def move_player(self,keys):
        if keys[pygame.K_LEFT]:
            self.rect.move_ip(-self.vel,0)
        if keys[pygame.K_RIGHT]:
            self.rect.move_ip(self.vel,0)
        if keys[pygame.K_UP]:
            self.rect.move_ip(0,-self.vel)
        if keys[pygame.K_DOWN]:
            self.rect.move_ip(0,self.vel)
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > self.screen_width:
            self.rect.right = self.screen_width
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= self.screen_height:
            self.rect.bottom = self.screen_height
        
class Missile (pygame.sprite.Sprite):
    def __init__(self,speed):
        super().__init__()
        self.speed = speed
        self.surf = pygame.image.load(os.path.join(BASE, "missile.png")).convert()
        self.surf = pygame.transform.scale(self.surf, (10,20))
        self.mask = pygame.mask.from_surface(self.surf)
        self.rect = self.surf.get_rect()
        
    def update(self):
        self.rect.move_ip(0,-self.speed)
        if self.rect.bottom <= 0:
            self.kill()
            
            
class BadGuy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.screen_width = 900
        self.screen_height = 600
        self.surf = pygame.image.load(os.path.join(BASE, "alien1.png")).convert()
        self.surf = pygame.transform.scale(self.surf, (45,45))
        self.mask = pygame.mask.from_surface(self.surf)
        self.rect = self.surf.get_rect(center=(random.randint(10, self.screen_width), random.randint(-100, -35)))
        self.speed = random.randint(1,2)
        
    def update(self):
        self.rect.move_ip(0, self.speed)
        if self.rect.bottom > self.screen_height:
            self.kill()
            MainGame.alien_score += 2


# MAIN MainGame LOOP ------------------------------------------------------------
class MainGame():
    alien_score = 0
    def __init__(self, window):
        self.window = window
        
        # VARIABLES ------------------------------------------------------------

        self.screen_width = 800
        self.screen_height = 600
        self.fired = 0
        self.alien_pop_time = 1250
        self.player_speed = 1
        self.missile_speed = 1
        self.player_score = 0
        #self.alien_score = 0
        self.game_on = True

        self.setup()

    def setup(self):
        # SETUP GAME WINDOW ------------------------------------------------------------     

        pygame.display.set_caption('Alien Invasion!')
        self.backgrnd = pygame.image.load(os.path.join(BASE, "background.jpg")).convert()
        self.backgrnd = pygame.transform.scale(self.backgrnd,(self.screen_width,self.screen_height))
        # CUSTOM EVENT FOR ADDING ENEMIES ------------------------------------------------------------

        self.ADD_BAD_GUY = pygame.USEREVENT + 1
        pygame.time.set_timer(self.ADD_BAD_GUY, self.alien_pop_time)

        # INSTANTIATE A PLAYER ------------------------------------------------------------

        self.player = Player(400, 500, 80, 80, self.player_speed)

        # SETUP SPRITE GROUPS ------------------------------------------------------------

        self.players = pygame.sprite.Group()
        self.missiles = pygame.sprite.Group()
        self.bad_guys = pygame.sprite.Group()
        self.all_sprites = pygame.sprite.Group()
        self.players.add(self.player)
        self.all_sprites.add(self.player)

    # FUNCTION USED TO PRINT SCORE OR END OF GAME ------------------------------------------------------------

    def show_text(self, size):
        white = (255, 255, 255)
        global game_on
        
        if self.game_on == True:
            text1 = 'player: ' + str(self.player_score)
            text2 = 'bad guys: ' + str(self.alien_score)
            place1 = (5,10)
            place2 = (660,10)
        else:
            text1 = 'Game Over!'
            text2 = 'Your Score: ' + str(self.player_score - self.alien_score)
            place1 = (275,200)
            place2 = (275,275)
            
        font = pygame.font.Font(None, size)
        text = font.render(text1, True, white)
        self.window.blit(text, place1)
        text = font.render(text2, True, white)
        self.window.blit(text, place2)

    def game(self):
        self.window.fill((255, 255, 255))
        self.window.blit(self.backgrnd,(0,0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return Result(False, self.player_score-self.alien_score)

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_SPACE:
                    self.fired -= 1
            
            #add a new enemy?
            if event.type == self.ADD_BAD_GUY:
                enemy = BadGuy()
                self.bad_guys.add(enemy)
                self.all_sprites.add(enemy)
        
        #use keyboard spacebar to shoot a missile and arrow keys to move character
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_SPACE] and self.fired < 1:
            self.fired += 1
            missile = Missile(self.missile_speed)
            missile.rect.x = int(self.player.rect.x + self.player.width/2 - 5)
            missile.rect.y = self.player.rect.y
            self.missiles.add(missile)
            self.all_sprites.add(missile)
        
        self.player.move_player(keys)
            
        for entity in self.all_sprites:
            self.window.blit(entity.surf,entity.rect)
        
        self.all_sprites.update()
        
        #check for alien shot down or collision with player
        if pygame.sprite.groupcollide(self.missiles, self.bad_guys, True, True):
            self.player_score += 1
        if pygame.sprite.spritecollideany(self.player, self.bad_guys):
            for enemy in self.bad_guys:
                offset = (enemy.rect.x-self.player.rect.x, enemy.rect.y-self.player.rect.y)
                
                if self.player.mask.overlap(enemy.mask,offset):
                    self.player.kill()
                    game_on = False
                    self.show_text(70)
                    pygame.display.update()
                    time.sleep(5)
                    return Result(False, self.player_score-self.alien_score)
        
        #Display scores
        self.show_text(30)
        return Result(True, 0)

'''
screen_size = [900, 600]
screen = pygame.display.set_mode(screen_size)
f = Game(screen)
f.setup()
while True:
    f.game("f")'''