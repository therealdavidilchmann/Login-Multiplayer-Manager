
class Result:
    def __init__(self, running, score):
        self.running = running
        self.score = score